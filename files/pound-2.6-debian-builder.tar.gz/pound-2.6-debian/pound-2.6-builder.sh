#!/bin/bash
set -e

# Download Pound and set up debian packaging config
curl http://www.apsis.ch/pound/Pound-2.6.tgz >pound_2.6.orig.tar.gz
tar xvfz pound_2.6.orig.tar.gz
cp -a pound-2.6-debian Pound-2.6/debian

# Build it!
cd Pound-2.6
debuild -us -uc
cd ..

# Cleanup
rm -rf Pound-2.6
